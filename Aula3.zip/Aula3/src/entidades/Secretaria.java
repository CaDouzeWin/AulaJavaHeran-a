package entidades;

public class Secretaria extends Funcionario {
    private String Ramal;

    public Secretaria(String nome, double salario, String Ramal) {
        super(nome, salario);
        this.Ramal = Ramal;
    }

    public String getRamal() {
        return Ramal;
    }

    public void setRamal(String Ramal) {
        this.Ramal = Ramal;
    }
}