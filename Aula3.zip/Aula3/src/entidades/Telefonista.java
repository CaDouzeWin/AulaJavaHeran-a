package entidades;

public class Telefonista extends Funcionario {
    private String codEstacao;

    public Telefonista(String nome, double salario, String codEstacao) {
        super(nome, salario);
        this.codEstacao = codEstacao;
    }

    public String getCodEstacao() {
        return codEstacao;
    }

    public void setCodEstacao(String codEstacao) {
        this.codEstacao = codEstacao;
    }
}