package Application;

import java.util.ArrayList;
import java.util.Scanner;
import entidades.Funcionario;
import entidades.Gerente;
import entidades.Secretaria;
import entidades.Telefonista;





public class App{
    private static ArrayList<Gerente> gerentes = new ArrayList<>();
    private static ArrayList<Telefonista> telefonistas = new ArrayList<>();
    private static ArrayList<Secretaria> secretarias = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\nMenu Principal:");
            System.out.println("1) Lista de Gerentes");
            System.out.println("2) Lista de Telefonistas");
            System.out.println("3) Lista de Secretarias");
            System.out.println("4) Sair");
            System.out.print("Aperte uma das teclas para realizar uma ação: ");

            int escolha = scanner.nextInt();
            scanner.nextLine(); 

            switch (escolha) {
                case 1:
                    menuGerentes();
                    break;
                case 2:
                    menuTelefonistas();
                    break;
                case 3:
                    menuSecretarias();
                    break;
                case 4:
                    System.out.println("Programa encerrado.");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }
    }

    private static void menuGerentes() {
        while (true) {
            System.out.println("\nMenu Gerentes:");
            System.out.println("1) Inserir novo gerente");
            System.out.println("2) Listar gerentes existentes");
            System.out.println("3) Voltar ao menu principal");
            System.out.print("Selecione uma das opções disponíveis: ");

            int escolha = scanner.nextInt();
            scanner.nextLine(); 

            switch (escolha) {
                case 1:
                    inserirGerente();
                    break;
                case 2:
                    listarGerentes();
                    break;
                case 3:
                    return; 
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }
    }

    private static void menuTelefonistas() {
        while (true) {
            System.out.println("\nMenu Telefonistas:");
            System.out.println("1) Inserir nova telefonista");
            System.out.println("2) Listar telefonistas existentes");
            System.out.println("3) Voltar ao menu principal");
            System.out.print("Selecione uma das opções disponíveis: ");

            int escolha = scanner.nextInt();
            scanner.nextLine(); 

            switch (escolha) {
                case 1:
                    inserirTelefonista();
                    break;
                case 2:
                    listarTelefonistas();
                    break;
                case 3:
                    return; // Retorna ao menu principal
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }
    }

    private static void menuSecretarias() {
        while (true) {
            System.out.println("\nMenu Secretarias:");
            System.out.println("1) Inserir nova secretaria");
            System.out.println("2) Listar secretarias existentes");
            System.out.println("3) Voltar ao menu principal");
            System.out.print("Selecione uma das opções disponíveis: ");

            int escolha = scanner.nextInt();
            scanner.nextLine(); // Limpa o buffer

            switch (escolha) {
                case 1:
                    inserirSecretaria();
                    break;
                case 2:
                    listarSecretarias();
                    break;
                case 3:
                    return; // Retorna ao menu principal
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }
    }

    private static void inserirGerente() {
        System.out.print("Digite o nome do gerente: ");
        String nome = scanner.nextLine();
        System.out.print("Digite o salário mensal do gerente: ");
        double salario = scanner.nextDouble();
        scanner.nextLine(); 

        System.out.print("Digite o nome de usuário do gerente: ");
        String usuario = scanner.nextLine();
        System.out.print("Digite a senha do gerente: ");
        String senha = scanner.nextLine();

        Gerente gerente = new Gerente(nome, salario, usuario, senha);
        gerentes.add(gerente);

        System.out.println("Gerente adicionado com sucesso!");
    }

    private static void listarGerentes() {
        if (gerentes.isEmpty()) {
            System.out.println("Não existem gerentes cadastrados.");
        } else {
            System.out.println("\nLista de Gerentes:");
            for (int i = 0; i < gerentes.size(); i++) {
                Gerente gerente = gerentes.get(i);
                System.out.println("Gerente " + (i + 1));
                System.out.println("Nome: " + gerente.getNome());
                System.out.println("Salário: " + gerente.getSalario());
                System.out.println("Nome de Usuário: " + gerente.getUsuario());
                System.out.println("Senha: " + gerente.getSenha());
                System.out.println("Bonificação: " + gerente.Bonificacao());
                System.out.println("Salário total: " + (gerente.getSalario()+gerente.Bonificacao()));
                System.out.println();
            }
        }
    }

    private static void inserirTelefonista() {
        System.out.print("Digite o nome da telefonista: ");
        String nome = scanner.nextLine();
        System.out.print("Digite o salário da telefonista: ");
        double salario = scanner.nextDouble();
        scanner.nextLine(); 

        System.out.print("Digite o código de estação de trabalho da telefonista: ");
        String codEstacao = scanner.nextLine();

        Telefonista telefonista = new Telefonista(nome, salario, codEstacao);
        telefonistas.add(telefonista);

        System.out.println("Telefonista adicionada com sucesso!");
    }

    private static void listarTelefonistas() {
        if (telefonistas.isEmpty()) {
            System.out.println("Não existem telefonistas cadastradas.");
        } else {
            System.out.println("\nLista de Telefonistas:");
            for (int i = 0; i < telefonistas.size(); i++) {
                Telefonista telefonista = telefonistas.get(i);
                System.out.println("Telefonista " + (i + 1));
                System.out.println("Nome: " + telefonista.getNome());
                System.out.println("Salário: " + telefonista.getSalario());
                System.out.println("Código de Estação de Trabalho: " + telefonista.getCodEstacao());
                System.out.println("Bonificação: " + telefonista.Bonificacao());
                System.out.println("Salário total: " + (telefonista.getSalario()+telefonista.Bonificacao()));
                System.out.println();
            }
        }
    }

    private static void inserirSecretaria() {
        System.out.print("Digite o nome da secretaria: ");
        String nome = scanner.nextLine();
        System.out.print("Digite o salário da secretaria: ");
        double salario = scanner.nextDouble();
        scanner.nextLine(); 

        System.out.print("Digite o número de ramal da secretaria: ");
        String numeroRamal = scanner.nextLine();

        Secretaria secretaria = new Secretaria(nome, salario, numeroRamal);
        secretarias.add(secretaria);

        System.out.println("Secretaria adicionada com sucesso!");
    }

    private static void listarSecretarias() {
        if (secretarias.isEmpty()) {
            System.out.println("Não existem secretarias cadastradas.");
        } else {
            System.out.println("\nLista de Secretarias:");
            for (int i = 0; i < secretarias.size(); i++) {
                Secretaria secretaria = secretarias.get(i);
                System.out.println("Secretaria " + (i + 1));
                System.out.println("Nome: " + secretaria.getNome());
                System.out.println("Salário: " + secretaria.getSalario());
                System.out.println("Número de Ramal: " + secretaria.getRamal());
                System.out.println("Bonificação: " + secretaria.Bonificacao());
                System.out.println("Salário total: " + (secretaria.getSalario()+secretaria.Bonificacao()));
                System.out.println();
            }
        }
    }
}